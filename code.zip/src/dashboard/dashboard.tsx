import React, { useEffect } from "react"
import Cascading from "./components/filters/cascading"
import axios from "axios"

export default function Dashboard(){
 
    useEffect(() => {

        
    }, [])
    return (<>
        <Cascading/>
        {/* {value ? value : 0} */}
    </>)
    
}